const emptyScanButton = document.getElementById("emptyScanButton");
const scoreToggle = document.getElementById("scoreToggle");
const scoreDetails = document.getElementById("scoreDetails");
const statusBadge = document.getElementById("statusBadge");
const pageHost = document.getElementById("pageHost");
const results = document.getElementById("results");
const emptyState = document.getElementById("emptyState");
const scoreRing = document.getElementById("scoreRing");
const scoreValue = document.getElementById("scoreValue");
const scoreHeadline = document.getElementById("scoreHeadline");
const confidenceChip = document.getElementById("confidenceChip");
const signalTotal = document.getElementById("signalTotal");
const signalBar = document.getElementById("signalBar");
const scoreBreakdown = document.getElementById("scoreBreakdown");
const flagList = document.getElementById("flagList");
const flagCount = document.getElementById("flagCount");
const highlightToggle = document.getElementById("highlightToggle");
const analysisButton = document.getElementById("analysisButton");
const analysisPanel = document.getElementById("analysisPanel");
const analysisSummary = document.getElementById("analysisSummary");
const analysisScores = document.getElementById("analysisScores");
const analysisSentences = document.getElementById("analysisSentences");
const analysisSourceCues = document.getElementById("analysisSourceCues");
const analysisImages = document.getElementById("analysisImages");
const downloadReportButton = document.getElementById("downloadReportButton");
const premiumIdeas = document.getElementById("premiumIdeas");

let currentState = null;
let analysisOpen = false;
let currentPageKey = "";

const premiumRoadmap = [
  "Claim-by-claim source verification",
  "Primary-source matching",
  "Citation quality scoring",
  "Image provenance checks",
  "Video frame provenance",
  "AI-generated media signals",
  "Source reputation memory",
  "Compare coverage across outlets",
  "Saved reliability reports",
  "Shareable review links",
  "Team workspaces",
  "Browser history risk trends",
  "Custom watchlists",
  "Research mode for long reads",
  "Exportable PDF briefs",
  "Follow-up questions",
  "Fact-check database matching",
  "Bias and framing timeline",
  "Newsletter and PDF scanning",
  "API access for teams"
];

function chromeMessage(payload) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(payload, (response) => {
      const error = chrome.runtime.lastError;
      if (error) {
        resolve({ ok: false, error: error.message || "Could not connect to PRISM." });
        return;
      }
      resolve(response || { ok: false, error: "No response from PRISM." });
    });
  });
}

function clamp(value, min = 0, max = 100) {
  return Math.max(min, Math.min(max, value));
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function setStatus(status, text) {
  statusBadge.className = `status-badge ${status}`;
  statusBadge.textContent = text;
}

function scoreHeadlineFor(score) {
  if (score >= 80) return "Strong reliability signals";
  if (score >= 60) return "Mixed reliability signals";
  return "Needs closer review";
}

function renderSignalGraph(flags = []) {
  const counts = {
    high: flags.filter((flag) => flag.severity === "high").length,
    medium: flags.filter((flag) => flag.severity === "medium").length,
    low: flags.filter((flag) => flag.severity === "low").length
  };
  const total = Math.max(1, counts.high + counts.medium + counts.low);
  signalTotal.textContent = `${counts.high + counts.medium + counts.low} signal${counts.high + counts.medium + counts.low === 1 ? "" : "s"}`;
  signalBar.innerHTML = `
    <span class="high" style="width:${(counts.high / total) * 100}%"></span>
    <span class="medium" style="width:${(counts.medium / total) * 100}%"></span>
    <span class="low" style="width:${(counts.low / total) * 100}%"></span>
  `;
}

function renderScoreBreakdown(result = {}) {
  const subscores = result.subscores || {};
  const items = [
    ["Evidence", `${subscores.evidence ?? "--"}/100`, "Unsupported claims and vague sourcing lower this metric."],
    ["Sources", `${subscores.sourceTransparency ?? "--"}/100`, "Byline, date, links, quotes, and references raise transparency."],
    ["Tone", `${subscores.loadedLanguage ?? "--"}/100`, "Loaded wording, certainty framing, urgency, and personal attacks lower this metric."],
    ["Claim risk", `${subscores.claimRisk ?? "--"}/100`, "Speculative, causal, or numeric claims need stronger support."],
    ["AI-likeness", `${subscores.aiLikeness ?? "--"}/100`, "Formulaic writing patterns can lower this style metric but do not prove AI authorship."]
  ];

  scoreBreakdown.innerHTML = items.map(([title, value, explanation]) => `
    <li>
      <strong>${escapeHtml(title)} ${escapeHtml(value)}</strong>
      <span>${escapeHtml(explanation)}</span>
    </li>
  `).join("");
}

function renderFlags(flags = [], highlightsApplied = 0) {
  const visibleFlags = flags.slice(0, 6);
  flagCount.textContent = `${highlightsApplied || visibleFlags.length} marked`;

  if (!visibleFlags.length) {
    flagList.innerHTML = `<p class="muted">No strong inline signals on this page.</p>`;
    return;
  }

  flagList.innerHTML = visibleFlags.map((flag) => `
    <button class="flag-item" type="button" data-flag-category="${escapeHtml(flag.category)}" data-flag-text="${escapeHtml(flag.text)}">
      <div>
        <strong>${escapeHtml(flag.category)}</strong>
        <p>${escapeHtml(flag.reason)}</p>
      </div>
      <span class="severity ${escapeHtml(flag.severity)}">${escapeHtml(flag.severity)}</span>
    </button>
  `).join("");
}

function sortedImagesForReview(images = []) {
  return [...images].sort((a, b) => {
    const signalDelta = (b.aiSignalCount || 0) - (a.aiSignalCount || 0);
    if (signalDelta) return signalDelta;
    const areaA = (a.naturalWidth || a.width || 0) * (a.naturalHeight || a.height || 0);
    const areaB = (b.naturalWidth || b.width || 0) * (b.naturalHeight || b.height || 0);
    return areaB - areaA;
  });
}

function imageSignalLabel(image = {}) {
  if ((image.aiSignalCount || 0) >= 3) return "Strong AI signal";
  if ((image.aiSignalCount || 0) >= 1) return "Possible AI signal";
  return "No AI signal";
}

function formatScanTime(ms = 0) {
  const value = Math.max(0, Number(ms) || 0);
  if (value < 100) return "<0.1s";
  if (value < 10000) return `${(value / 1000).toFixed(1)}s`;
  return `${Math.round(value / 1000)}s`;
}

function renderImageReview(meta = {}) {
  const images = meta.images || [];
  const reviewedImages = sortedImagesForReview(images).slice(0, 8);
  const possibleAiCount = images.filter((image) => (image.aiSignalCount || 0) > 0).length;

  analysisImages.innerHTML = `
    <div class="panel-header compact-header">
      <h4>Image review</h4>
      <span class="mini-label">${escapeHtml(String(possibleAiCount))} possible AI</span>
    </div>
    ${reviewedImages.length ? `
      <div class="image-review-list">
        ${reviewedImages.map((image) => {
          const dimensions = `${image.naturalWidth || image.width || 0}x${image.naturalHeight || image.height || 0}`;
          const signals = image.aiSignals || [];
          const level = image.aiSignalLevel || "low";
          return `
            <article class="image-review-item">
              <img src="${escapeHtml(image.src)}" alt="${escapeHtml(image.alt || "Page image preview")}" loading="lazy" />
              <div>
                <div class="image-review-title">
                  <strong>${escapeHtml(image.fileName || image.alt || image.host || `Image ${Number(image.index || 0) + 1}`)}</strong>
                  <span class="severity ${escapeHtml(level)}">${escapeHtml(imageSignalLabel(image))}</span>
                </div>
                <p>${escapeHtml([dimensions, image.fileType ? image.fileType.toUpperCase() : "", image.host].filter(Boolean).join(" - "))}</p>
                ${image.alt ? `<p>Alt: ${escapeHtml(image.alt)}</p>` : `<p>Alt text missing</p>`}
                <a class="image-source-link" href="${escapeHtml(image.src)}" target="_blank" rel="noreferrer">Open image</a>
                <ul class="image-signal-list">
                  ${signals.length ? signals.map((signal) => `<li>${escapeHtml(signal)}</li>`).join("") : `<li>No AI-generation metadata signal found.</li>`}
                </ul>
              </div>
            </article>
          `;
        }).join("")}
      </div>
      <p class="muted">AI image review uses page metadata and source hints only. Up to ${escapeHtml(String(meta.imageMetadataLimit || images.length))} images are reviewed; this is not forensic proof of image origin.</p>
    ` : `<p class="muted">No page images were available for review.</p>`}
  `;
}

function buildDownloadReport(state = {}) {
  const page = state.page || {};
  const result = state.result || {};
  const meta = page.meta || {};

  return {
    generatedAt: new Date().toISOString(),
    page: {
      title: page.title || "",
      url: page.url || "",
      host: page.host || ""
    },
    score: result.score,
    confidence: result.confidence,
    scanTiming: state.scanTiming || {},
    subscores: result.subscores || {},
    stats: result.stats || {},
    sourceCues: {
      byline: meta.byline || "",
      publishedTime: meta.publishedTime || "",
      linkCount: meta.linkCount || 0,
      externalLinkCount: meta.externalLinkCount || 0,
      internalLinkCount: meta.internalLinkCount || 0,
      imageCount: meta.imageCount || 0,
      readableWordCount: meta.readableWordCount || 0,
      readableCharCount: meta.readableCharCount || 0,
      analyzedCharLimit: meta.analyzedCharLimit || 0
    },
    summary: result.summary || [],
    findings: result.flags || [],
    imageReview: {
      note: "AI image review is based on browser-visible metadata and page/source hints, not forensic image proof.",
      metadataLimit: meta.imageMetadataLimit || (meta.images || []).length,
      images: meta.images || []
    }
  };
}

function safeFileName(value = "prism-report") {
  return String(value || "prism-report")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "prism-report";
}

function downloadCurrentReport() {
  if (!currentState?.result) return;

  const report = buildDownloadReport(currentState);
  const blob = new Blob([JSON.stringify(report, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  const host = safeFileName(currentState.page?.host || "page");
  const date = new Date().toISOString().slice(0, 10);

  link.href = url;
  link.download = `prism-${host}-${date}.json`;
  document.body.appendChild(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1000);

  downloadReportButton.textContent = "Report downloaded";
  setTimeout(() => {
    downloadReportButton.textContent = "Download report";
  }, 1400);
}

function renderAnalysis(state) {
  const result = state?.result || {};
  const stats = result.stats || {};
  const meta = state?.page?.meta || {};
  const scanTiming = state?.scanTiming || {};
  const catalog = result.catalog || {};
  const summary = result.summary || [];
  const subscores = result.subscores || {};

  analysisSummary.innerHTML = `
    <div class="analysis-grid">
      <div><strong>${escapeHtml(String(stats.wordCount || 0))}</strong><span>Words</span></div>
      <div><strong>${escapeHtml(String(stats.sentenceCount || 0))}</strong><span>Sentences</span></div>
      <div><strong>${escapeHtml(String((result.flags || []).length))}</strong><span>Findings</span></div>
      <div><strong>${escapeHtml(String(stats.quoteCount || 0))}</strong><span>Quotes</span></div>
      <div><strong>${escapeHtml(formatScanTime(scanTiming.displayedDurationMs))}</strong><span>Scan time</span></div>
      <div><strong>${escapeHtml(String(catalog.scanCoveragePercent ?? stats.scanCoveragePercent ?? 100))}%</strong><span>Article coverage</span></div>
    </div>
    <ul class="analysis-list">
      ${summary.slice(0, 4).map((item) => `<li>${escapeHtml(item)}</li>`).join("")}
    </ul>
  `;

  analysisScores.innerHTML = Object.entries({
    Objectivity: subscores.objectivity,
    Evidence: subscores.evidence,
    "Source transparency": subscores.sourceTransparency,
    "Loaded language": subscores.loadedLanguage,
    "AI-likeness": subscores.aiLikeness,
    "Claim risk": subscores.claimRisk
  }).map(([label, raw]) => {
    const value = clamp(raw ?? 0);
    return `
      <div class="analysis-score">
        <span>${escapeHtml(label)}</span>
        <strong>${value}</strong>
        <div class="meter"><span style="width:${value}%"></span></div>
      </div>
    `;
  }).join("");

  const contributors = result.contributors || [];
  analysisSentences.innerHTML = `
    <h4>Sentences affecting scores</h4>
    ${contributors.length ? contributors.map((group) => `
      <section class="sentence-group">
        <strong>${escapeHtml(group.label)}</strong>
        ${group.sentences.map((item) => `
          <button class="sentence-hit" type="button" data-flag-category="${escapeHtml(item.category)}" data-flag-text="${escapeHtml(item.text)}">
            <span>${escapeHtml(item.category)} · ${escapeHtml(item.severity)}</span>
            <p>${escapeHtml(item.text)}</p>
          </button>
        `).join("")}
      </section>
    `).join("") : `<p class="muted">No score-driving sentences found in this pass.</p>`}
  `;

  analysisSourceCues.innerHTML = `
    <h4>Source cues</h4>
    <div class="source-cue-grid">
      <div><strong>${escapeHtml(String(meta.linkCount || 0))}</strong><span>Total links</span></div>
      <div><strong>${escapeHtml(String(meta.externalLinkCount ?? 0))}</strong><span>External links</span></div>
      <div><strong>${escapeHtml(String(meta.internalLinkCount ?? 0))}</strong><span>Internal links</span></div>
      <div><strong>${escapeHtml(String(stats.imageCount ?? meta.imageCount ?? (meta.images || []).length))}</strong><span>Images</span></div>
      <div><strong>${escapeHtml(String((meta.images || []).length))}</strong><span>Images scanned</span></div>
      <div><strong>${escapeHtml(String((meta.images || []).filter((image) => (image.aiSignalCount || 0) > 0).length))}</strong><span>Possible AI images</span></div>
      <div><strong>${escapeHtml(meta.byline ? "Found" : "Missing")}</strong><span>Byline</span></div>
      <div><strong>${escapeHtml(meta.publishedTime ? "Found" : "Missing")}</strong><span>Date</span></div>
    </div>
  `;

  renderImageReview(meta);
}

function renderPremiumIdeas() {
  premiumIdeas.innerHTML = premiumRoadmap.map((item) => `<li>${escapeHtml(item)}</li>`).join("");
}

function renderHighlightToggle(visible = true) {
  highlightToggle.classList.toggle("active", visible);
  highlightToggle.setAttribute("aria-pressed", String(visible));
}

function renderState(state) {
  if (!state || state.status === "scanning") {
    setStatus("scanning", "Scanning");
    if (results && !results.classList.contains("hidden")) return;
    emptyState.querySelector("p").textContent = "PRISM watches the active tab and marks reliability signals directly on the page.";
    emptyState.classList.remove("hidden");
    results.classList.add("hidden");
    return;
  }

  const nextPageKey = `${state.tabId || ""}|${state.page?.url || state.page?.host || ""}`;
  if (currentPageKey && nextPageKey !== currentPageKey) {
    analysisOpen = false;
    analysisPanel.classList.add("hidden");
    analysisButton.textContent = "Run analysis";
  }
  currentPageKey = nextPageKey;
  currentState = state;

  if (state.status === "empty") {
    setStatus("ready", "Quiet");
    pageHost.textContent = state.page?.host || "Watching active tab";
    emptyState.querySelector("p").textContent = "No strong inline signals are marked on this page right now.";
    emptyState.classList.remove("hidden");
    results.classList.add("hidden");
    return;
  }

  if (state.status === "error") {
    setStatus("error", "Paused");
    emptyState.classList.remove("hidden");
    results.classList.add("hidden");
    emptyState.querySelector("p").textContent = state.error || "This page cannot be reviewed.";
    return;
  }

  const result = state.result;
  const score = clamp(result?.score ?? 0);
  const degrees = Math.round((score / 100) * 360);

  pageHost.textContent = state.page?.host || "Active tab";
  setStatus("ready", "Active");
  scoreRing.style.background = `conic-gradient(var(--teal) ${degrees}deg, #e8ece7 ${degrees}deg)`;
  scoreValue.textContent = String(score);
  scoreHeadline.textContent = scoreHeadlineFor(score);
  confidenceChip.textContent = result?.confidence ? `${result.confidence} confidence` : "Signal review";

  renderHighlightToggle(state.highlightVisible !== false);
  renderSignalGraph(result?.flags || []);
  renderScoreBreakdown(result || {});
  renderFlags(result?.flags || [], state.highlightsApplied || 0);
  if (analysisOpen) renderAnalysis(state);

  emptyState.classList.add("hidden");
  results.classList.remove("hidden");
}

async function refreshState() {
  const response = await chromeMessage({ type: "PRISM_GET_ACTIVE_STATE" });
  if (response?.ok) renderState(response.state);
}

async function requestRescan() {
  setStatus("scanning", "Scanning");
  await chromeMessage({ type: "PRISM_RESCAN_ACTIVE_TAB" });
  setTimeout(refreshState, 850);
}

async function toggleHighlights() {
  const visible = !highlightToggle.classList.contains("active");
  renderHighlightToggle(visible);
  const response = await chromeMessage({ type: "PRISM_SET_HIGHLIGHTS_VISIBLE", visible });
  if (!response?.ok) renderHighlightToggle(!visible);
}

async function focusFlagFromEvent(event) {
  const item = event.target.closest(".flag-item, .sentence-hit");
  if (!item) return;

  await chromeMessage({
    type: "PRISM_FOCUS_FLAG",
    flag: {
      category: item.dataset.flagCategory,
      text: item.dataset.flagText
    }
  });
}

function runAnalysis() {
  analysisOpen = true;
  analysisButton.textContent = "Analysis updated";
  analysisPanel.classList.remove("hidden");
  if (currentState?.result) renderAnalysis(currentState);
  requestRescan();
}

emptyScanButton.addEventListener("click", requestRescan);
highlightToggle.addEventListener("click", toggleHighlights);
analysisButton.addEventListener("click", runAnalysis);
downloadReportButton.addEventListener("click", downloadCurrentReport);
flagList.addEventListener("click", focusFlagFromEvent);
analysisSentences.addEventListener("click", focusFlagFromEvent);
scoreToggle.addEventListener("click", () => {
  const isOpen = !scoreDetails.classList.contains("hidden");
  scoreDetails.classList.toggle("hidden", isOpen);
  scoreToggle.setAttribute("aria-expanded", String(!isOpen));
  scoreToggle.querySelector(".score-chevron").textContent = isOpen ? "+" : "-";
});

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type === "PRISM_SCAN_STATE_UPDATED") renderState(message.state);
});

renderPremiumIdeas();
refreshState();

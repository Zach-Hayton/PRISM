import { splitIntoSentences, countWords } from "./sentenceSplitter.js";
import {
  certaintyTerms,
  fallacyPatterns,
  hedgeTerms,
  identifierCatalog,
  signalGroups,
  vagueAuthorityPatterns
} from "./lexicons.js";
import { detectClaims } from "./claimDetector.js";
import { scoreAiLikeness } from "./aiLikeness.js";
import {
  aggregateScore,
  buildSubscores,
  confidenceFromStats,
  sourceTransparencyScore
} from "./scoring.js";

function includesTerm(sentence, term) {
  return sentence.toLowerCase().includes(term.toLowerCase());
}

function matchPhrase(sentence, phrase) {
  const escaped = phrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return new RegExp(`(^|\\W)${escaped}(\\W|$)`, "i").test(sentence);
}

function capToWordLimit(text, limit = 10000) {
  const words = String(text || "").split(/\s+/).filter(Boolean);
  return words.length > limit ? words.slice(0, limit).join(" ") : String(text || "");
}

function severityFromRisk(risk) {
  if (risk >= 5) return "high";
  if (risk >= 3) return "medium";
  return "low";
}

function sentencePreview(sentence) {
  return sentence.length > 220 ? `${sentence.slice(0, 217)}...` : sentence;
}

function addFlag(flags, flag) {
  flags.push({
    type: "language",
    matched: [],
    ...flag,
    text: sentencePreview(flag.text || "")
  });
}

function uniqueFlags(flags) {
  const seen = new Set();
  return flags.filter((flag) => {
    const key = `${flag.category}|${flag.text}`.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

function countQuotes(text) {
  return (String(text || "").match(/["'][^"']{20,}["']/g) || []).length;
}

function buildSummary({ flags, aiLikeness, subscores, stats }) {
  const summary = [];

  if (subscores.evidence < 65) {
    summary.push("Evidence score is lower because several claims use statistics, causation, predictions, or vague sourcing without clear support.");
  }

  if (subscores.loadedLanguage < 70) {
    summary.push("Tone score is lower because PRISM found loaded wording, certainty framing, urgency, or personal attack patterns.");
  }

  if (aiLikeness.score < 70) {
    summary.push("Some AI-like writing signals appeared. This is a style signal, not proof of AI authorship.");
  }

  if (subscores.sourceTransparency >= 75) {
    summary.push("The page has positive transparency signals such as links, byline/date metadata, or quote/source cues.");
  } else {
    summary.push("Source transparency could be stronger. Look for named sources, dates, primary links, and direct evidence.");
  }

  if (!flags.length && stats.wordCount > 150) {
    summary.push("No major quick-scan flags were found in the live local scan.");
  }

  return summary.slice(0, 5);
}

function buildContributors(flags) {
  const groups = [
    ["Evidence score", (flag) => flag.category === "Unsupported claim" || flag.category === "Vague sourcing"],
    ["Tone score", (flag) => flag.type === "language"],
    ["Framing score", (flag) => flag.type === "framing"],
    ["AI-likeness score", (flag) => flag.category === "AI-like signal"]
  ];

  return groups.map(([label, predicate]) => ({
    label,
    sentences: flags.filter(predicate).slice(0, 6).map((flag) => ({
      category: flag.category,
      severity: flag.severity,
      text: flag.text,
      reason: flag.reason,
      matched: flag.matched || []
    }))
  })).filter((group) => group.sentences.length);
}

export function analyzeText(text, meta = {}, page = {}) {
  const sourceWordCount = meta.readableWordCount || countWords(text);
  const scanText = capToWordLimit(text, identifierCatalog.liveScanWordLimit);
  const sentences = splitIntoSentences(scanText);
  const wordCount = countWords(scanText);
  const scanCoveragePercent = sourceWordCount ? Math.min(100, Math.round((wordCount / sourceWordCount) * 100)) : 0;
  const flags = [];

  for (const sentence of sentences) {
    for (const group of signalGroups) {
      const hits = group.phrases.filter((phrase) => matchPhrase(sentence, phrase)).slice(0, 4);
      if (!hits.length) continue;

      addFlag(flags, {
        category: group.category,
        severity: hits.length >= 2 && group.severity !== "high" ? "high" : group.severity,
        type: group.type,
        text: sentence,
        matched: hits,
        reason: `${group.reason} Matched: ${hits.join(", ")}.`
      });
    }

    if (vagueAuthorityPatterns.some((pattern) => pattern.test(sentence))) {
      addFlag(flags, {
        category: "Vague sourcing",
        severity: "medium",
        type: "evidence",
        text: sentence,
        reason: "References broad authorities or groups without clearly naming the source."
      });
    }

    const certaintyHits = certaintyTerms.filter((term) => includesTerm(sentence, term)).slice(0, 4);
    if (certaintyHits.length) {
      addFlag(flags, {
        category: "Overstated certainty",
        severity: certaintyHits.length >= 2 ? "high" : "medium",
        type: "language",
        text: sentence,
        matched: certaintyHits,
        reason: `Uses absolute wording where evidence or uncertainty may matter. Matched: ${certaintyHits.join(", ")}.`
      });
    }

    const hedgeHits = hedgeTerms.filter((term) => includesTerm(sentence, term)).slice(0, 4);
    if (hedgeHits.length >= 3) {
      addFlag(flags, {
        category: "Hedged claim",
        severity: "low",
        type: "evidence",
        text: sentence,
        matched: hedgeHits,
        reason: `Uses several uncertainty markers. Matched: ${hedgeHits.join(", ")}.`
      });
    }

    const fallacy = fallacyPatterns.find((item) => item.regex.test(sentence));
    if (fallacy) {
      addFlag(flags, {
        category: `Reasoning pattern: ${fallacy.name}`,
        severity: "medium",
        type: "framing",
        text: sentence,
        reason: fallacy.reason
      });
    }
  }

  const claims = detectClaims(sentences, meta);
  for (const claim of claims) {
    if (claim.risk >= 3) {
      addFlag(flags, {
        category: "Unsupported claim",
        severity: severityFromRisk(claim.risk),
        type: "evidence",
        text: claim.sentence,
        reason: `Potentially needs evidence because it ${claim.reasons.join(", ")}.`
      });
    }
  }

  const aiLikeness = scoreAiLikeness(sentences, scanText);
  for (const reason of aiLikeness.reasons.slice(0, 3)) {
    const example = sentences.find((sentence) =>
      /furthermore|moreover|additionally|in conclusion|important to note|delve into|crucial role/i.test(sentence)
    ) || sentences[0];

    if (example) {
      addFlag(flags, {
        category: "AI-like signal",
        severity: aiLikeness.score < 60 ? "high" : "low",
        type: "style",
        text: example,
        reason: `${reason}. This signal is suggestive, not conclusive.`
      });
    }
  }

  const cleanFlags = uniqueFlags(flags)
    .sort((a, b) => {
      const weight = { high: 3, medium: 2, low: 1 };
      return (weight[b.severity] || 0) - (weight[a.severity] || 0);
    })
    .slice(0, 60);

  const stats = {
    wordCount,
    sourceWordCount,
    scanCoveragePercent,
    sentenceCount: sentences.length,
    linkCount: meta.linkCount || 0,
    imageCount: meta.imageCount ?? (meta.images || []).length,
    hasByline: Boolean(meta.byline),
    hasDate: Boolean(meta.publishedTime),
    quoteCount: countQuotes(scanText),
    title: page.title || "",
    host: page.host || ""
  };

  const sourceScore = sourceTransparencyScore(meta, stats);
  const unsupportedClaims = cleanFlags.filter((flag) => flag.category === "Unsupported claim").length;
  const loadedCount = cleanFlags.filter((flag) =>
    flag.category === "Loaded wording" ||
    flag.category === "Overstated certainty" ||
    flag.category === "Dehumanizing wording" ||
    flag.category === "Personal attack"
  ).length;

  const subscores = buildSubscores({
    flags: cleanFlags,
    aiLikeness,
    sourceScore,
    unsupportedClaims,
    loadedCount
  });

  const score = aggregateScore({
    flags: cleanFlags,
    aiLikeness,
    sourceScore,
    stats
  });

  const confidence = confidenceFromStats(stats, cleanFlags.length);
  const summary = buildSummary({ flags: cleanFlags, aiLikeness, subscores, stats });

  return {
    score,
    confidence,
    shortExplanation: "Local analysis based on text structure, sourcing, claims, and language/framing signals.",
    subscores,
    summary,
    flags: cleanFlags,
    stats,
    aiLikeness,
    contributors: buildContributors(cleanFlags),
    catalog: {
      ...identifierCatalog,
      scannedWordLimit: identifierCatalog.liveScanWordLimit,
      scannedWords: wordCount,
      sourceWords: sourceWordCount,
      scanCoveragePercent
    }
  };
}

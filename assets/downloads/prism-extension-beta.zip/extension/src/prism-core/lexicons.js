export const emotionalTerms = [
  "alarming", "appalling", "atrocious", "betrayal", "catastrophe", "collapse",
  "corrupt", "crisis", "dangerous", "devastating", "disaster", "disgrace",
  "doomed", "evil", "explosive", "horrific", "insane", "nightmare", "outrage",
  "panic", "reckless", "scandal", "shocking", "terrifying", "threat", "toxic",
  "unthinkable", "weaponized"
];

export const loadedTerms = [
  ...emotionalTerms,
  "attack on", "cover-up", "destroy", "disaster waiting to happen", "existential threat",
  "fraudulent", "hidden agenda", "radical", "rigged", "scam", "secret plot",
  "unprecedented attack", "war on"
];

export const certaintyTerms = [
  "always", "cannot be denied", "certainly", "clearly shows", "everyone knows",
  "guaranteed", "inevitably", "never", "no doubt", "obviously", "proves",
  "the fact is", "the truth is", "undeniable", "without question"
];

export const hedgeTerms = [
  "allegedly", "appears to", "could", "estimated", "likely", "may", "might",
  "possibly", "preliminary", "reportedly", "suggests"
];

export const signalGroups = [
  {
    id: "loaded-language",
    category: "Loaded wording",
    severity: "medium",
    type: "language",
    phrases: loadedTerms,
    reason: "Uses emotionally charged wording that can push interpretation."
  },
  {
    id: "absolute-certainty",
    category: "Overstated certainty",
    severity: "medium",
    type: "language",
    phrases: certaintyTerms,
    reason: "Uses absolute wording where evidence or uncertainty may matter."
  },
  {
    id: "urgency-pressure",
    category: "Urgency framing",
    severity: "medium",
    type: "framing",
    phrases: [
      "act now", "before it is too late", "before it's too late", "do not wait",
      "last chance", "right now", "time is running out", "urgent warning"
    ],
    reason: "Creates time pressure that may reduce careful evaluation."
  },
  {
    id: "hidden-knowledge",
    category: "Hidden knowledge claim",
    severity: "medium",
    type: "framing",
    phrases: [
      "cover up", "covered up", "hidden truth", "mainstream media won't tell you",
      "secret they do not want you to know", "the truth about", "they do not want you to know",
      "what they are hiding", "what you are not being told"
    ],
    reason: "Frames the claim as suppressed information without necessarily giving evidence."
  },
  {
    id: "clickbait",
    category: "Clickbait framing",
    severity: "medium",
    type: "framing",
    phrases: [
      "jaw-dropping", "shocking truth", "this changes everything", "what happened next",
      "will blow your mind", "you won't believe"
    ],
    reason: "Uses curiosity-gap framing common in low-information headlines."
  },
  {
    id: "dehumanizing",
    category: "Dehumanizing wording",
    severity: "high",
    type: "language",
    phrases: [
      "animals", "cockroaches", "filth", "infestation", "parasites", "plague",
      "rats", "vermin"
    ],
    reason: "Uses dehumanizing labels that can intensify bias or hostility."
  },
  {
    id: "insult-attack",
    category: "Personal attack",
    severity: "medium",
    type: "language",
    phrases: [
      "clown", "crook", "fraud", "idiot", "liar", "moron", "traitor"
    ],
    reason: "Attacks a person or group instead of supporting the claim."
  }
];

export const vagueAuthorityPatterns = [
  /\banalysts\s+(say|warn|believe|claim|suggest)\b/i,
  /\bcritics\s+(say|warn|argue|claim)\b/i,
  /\bexperts\s+(say|warn|believe|claim|agree)\b/i,
  /\binsiders\s+(say|claim|suggest|believe)\b/i,
  /\bmany\s+(believe|say|argue|claim)\b/i,
  /\bobservers\s+(say|warn|argue|claim)\b/i,
  /\bpeople are saying\b/i,
  /\breports\s+(say|claim|suggest|indicate)\b/i,
  /\bresearch proves\b/i,
  /\bsome\s+(say|argue|believe|claim)\b/i,
  /\bsources\s+(say|claim|suggest|indicate)\b/i,
  /\bstudies show\b/i,
  /\bit is widely believed\b/i
];

export const unsupportedClaimPatterns = [
  { label: "statistic", regex: /(\b\d+(\.\d+)?\s?%|\$\s?\d+|\b\d+(\.\d+)?\s?(million|billion|trillion|x|times)\b)/i },
  { label: "causal claim", regex: /\b(causes|caused|drives|forces|increases|leads to|prevents|reduces|responsible for|results in|will lead to)\b/i },
  { label: "prediction", regex: /\b(will|is going to|set to|poised to)\b.{0,90}\b(collapse|explode|fail|rise|fall|surge|crash|change)\b/i },
  { label: "comparison", regex: /\b(more than|less than|higher than|lower than|best|worst|largest|smallest|most|least)\b/i }
];

export const sourceCuePatterns = [
  /\baccording to\b/i,
  /\bcited by\b/i,
  /\bdata from\b/i,
  /\bevidence from\b/i,
  /\binterview with\b/i,
  /\bjournal\b/i,
  /\bpaper\b/i,
  /\breported by\b/i,
  /\bsource\b/i,
  /\bstudy by\b/i,
  /\bsurvey\b/i
];

export const aiLikePhrases = [
  "a testament to", "a wide range of", "additionally", "crucial role",
  "delve into", "furthermore", "in conclusion", "in today's digital age",
  "it is important to note", "leveraging", "moreover", "not only", "but also",
  "pave the way", "plays a crucial role", "robust solution", "seamlessly",
  "transformative", "underscore the importance", "various factors"
];

export const fallacyPatterns = [
  { name: "False dilemma", regex: /\beither\b.{0,90}\bor\b/i, reason: "Frames the issue as a limited either/or choice." },
  { name: "Slippery slope", regex: /\b(will inevitably lead to|slippery slope|next thing you know)\b/i, reason: "Suggests a chain of consequences without showing the chain of evidence." },
  { name: "Appeal to fear", regex: /\b(if we don't|before it's too late|dangerous precedent|existential threat)\b/i, reason: "Uses fear-based framing that may shape perception." },
  { name: "Personal attack", regex: /\b(idiot|moron|clown|traitor|crook|liar)\b/i, reason: "Attacks a person or group rather than directly addressing the claim." },
  { name: "Bandwagon", regex: /\b(everyone agrees|everyone knows|nobody believes|all reasonable people)\b/i, reason: "Leans on assumed consensus rather than evidence." }
];

export const clickbaitPatterns = signalGroups.find((group) => group.id === "clickbait").phrases.map(
  (phrase) => new RegExp(`\\b${phrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "i")
);

export const expansionFamilies = [
  { name: "emotional adjective + institution/person target", variants: 14200 },
  { name: "certainty verb + claim object", variants: 8600 },
  { name: "vague authority + reporting verb", variants: 6200 },
  { name: "urgency phrase + action object", variants: 5100 },
  { name: "hidden knowledge phrase + topic object", variants: 7400 },
  { name: "causal claim verb + outcome", variants: 6700 },
  { name: "comparison superlative + category", variants: 3900 }
];

export const identifierCatalog = {
  shippedPhraseCount: signalGroups.reduce((sum, group) => sum + group.phrases.length, 0) +
    vagueAuthorityPatterns.length + unsupportedClaimPatterns.length + sourceCuePatterns.length +
    aiLikePhrases.length + fallacyPatterns.length,
  expandedIdentifierEstimate: expansionFamilies.reduce((sum, family) => sum + family.variants, 0),
  targetCatalogSize: 100000,
  liveScanWordLimit: 50000,
  note: "The live extension ships compact local patterns and generated phrase-family coverage. The 100k catalog target is represented as expansion families so the live scan avoids loading every variant into every page pass."
};

export function clampScore(value) {
  return Math.max(0, Math.min(100, Math.round(value)));
}

export function confidenceFromStats(stats, flagCount) {
  if (stats.wordCount < 150) return "low";
  if (stats.wordCount > 600 && flagCount >= 4) return "high";
  return "medium";
}

export function aggregateScore({ flags, aiLikeness, sourceScore, stats }) {
  const severityWeight = { low: 1, medium: 2.5, high: 4.5 };

  const penalties = flags.reduce((sum, flag) => sum + (severityWeight[flag.severity] || 1), 0);
  const lengthGuard = stats.wordCount < 220 ? 0.55 : 1;
  const adjustedPenalty = penalties * lengthGuard;

  const base = 88;
  const sourceBonus = Math.max(-8, Math.min(8, (sourceScore - 60) / 5));
  const aiPenalty = Math.max(0, (75 - aiLikeness.score) / 3);

  return clampScore(base + sourceBonus - adjustedPenalty - aiPenalty);
}

export function buildSubscores({ flags, aiLikeness, sourceScore, unsupportedClaims, loadedCount }) {
  const vagueCount = flags.filter((flag) => flag.category === "Vague sourcing").length;
  const fallacyCount = flags.filter((flag) => flag.category.includes("Fallacy")).length;
  const framingCount = flags.filter((flag) => flag.type === "framing").length;
  const highCount = flags.filter((flag) => flag.severity === "high").length;

  return {
    objectivity: clampScore(90 - loadedCount * 5 - framingCount * 4 - fallacyCount * 8),
    evidence: clampScore(86 - unsupportedClaims * 7 - vagueCount * 5),
    sourceTransparency: clampScore(sourceScore),
    loadedLanguage: clampScore(100 - loadedCount * 7 - highCount * 3),
    aiLikeness: clampScore(aiLikeness.score),
    claimRisk: clampScore(100 - unsupportedClaims * 9)
  };
}

export function sourceTransparencyScore(meta = {}, stats = {}) {
  let score = 48;

  if (meta.byline) score += 12;
  if (meta.publishedTime) score += 12;
  if ((meta.linkCount || 0) >= 4) score += 10;
  if ((meta.linkCount || 0) >= 10) score += 6;
  if ((stats.quoteCount || 0) >= 2) score += 8;
  if ((stats.wordCount || 0) > 400 && (meta.linkCount || 0) === 0) score -= 16;

  return clampScore(score);
}

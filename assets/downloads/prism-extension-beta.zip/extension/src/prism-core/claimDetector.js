import { sourceCuePatterns, unsupportedClaimPatterns, vagueAuthorityPatterns } from "./lexicons.js";

const strongClaimPattern = /\b(is|are|was|were|has|have|will|must|should)\b/i;

export function detectClaims(sentences, meta = {}) {
  const externalLinks = (meta.links || []).filter((link) => {
    try {
      const url = new URL(link.href);
      return Boolean(url.hostname);
    } catch {
      return false;
    }
  });

  return sentences.map((sentence) => {
    const unsupportedMatches = unsupportedClaimPatterns.filter((pattern) => pattern.regex.test(sentence));
    const hasVagueAuthority = vagueAuthorityPatterns.some((pattern) => pattern.test(sentence));
    const hasStrongClaim = strongClaimPattern.test(sentence) && sentence.length > 55;
    const hasNearbyCitation = sourceCuePatterns.some((pattern) => pattern.test(sentence));

    let risk = 0;
    const reasons = [];

    for (const match of unsupportedMatches) {
      risk += match.label === "statistic" ? 3 : 2;
      reasons.push(`contains a ${match.label}`);
    }

    if (hasVagueAuthority) {
      risk += 3;
      reasons.push("uses vague sourcing");
    }

    if (hasStrongClaim) {
      risk += 1;
      reasons.push("makes a strong factual statement");
    }

    if (hasNearbyCitation) {
      risk -= 2;
      reasons.push("contains a source cue");
    }

    if (externalLinks.length > 5) {
      risk -= 1;
    }

    return {
      sentence,
      risk: Math.max(0, risk),
      reasons
    };
  }).filter((claim) => claim.risk > 0);
}

export function splitIntoSentences(text) {
  const normalized = String(text || "")
    .replace(/\s+/g, " ")
    .replace(/\u00a0/g, " ")
    .trim();

  if (!normalized) return [];

  const rough = normalized.match(/[^.!?]+[.!?]+["')\]]?|[^.!?]+$/g) || [normalized];

  return rough
    .map((sentence) => sentence.trim())
    .filter((sentence) => sentence.length > 20)
    .slice(0, 700);
}

export function countWords(text) {
  return (String(text || "").match(/\b[\w'-]+\b/g) || []).length;
}

import { aiLikePhrases } from "./lexicons.js";
import { countWords } from "./sentenceSplitter.js";

function standardDeviation(values) {
  if (!values.length) return 0;
  const mean = values.reduce((sum, value) => sum + value, 0) / values.length;
  const variance = values.reduce((sum, value) => sum + Math.pow(value - mean, 2), 0) / values.length;
  return Math.sqrt(variance);
}

export function scoreAiLikeness(sentences, text) {
  const lower = String(text || "").toLowerCase();
  const wordCount = countWords(text);
  const sentenceLengths = sentences.map((sentence) => countWords(sentence));
  const avgSentenceLength = sentenceLengths.length
    ? sentenceLengths.reduce((sum, value) => sum + value, 0) / sentenceLengths.length
    : 0;
  const lengthStd = standardDeviation(sentenceLengths);

  const phraseHits = aiLikePhrases.filter((phrase) => lower.includes(phrase)).length;
  const transitionHits = (lower.match(/\b(furthermore|moreover|additionally|therefore|consequently|in conclusion)\b/g) || []).length;
  const lowBurstiness = sentenceLengths.length >= 6 && lengthStd < 5 ? 1 : 0;
  const genericDensity = wordCount ? (phraseHits + transitionHits) / wordCount * 1000 : 0;

  let risk = 0;
  risk += Math.min(35, phraseHits * 7);
  risk += Math.min(20, transitionHits * 4);
  risk += lowBurstiness ? 16 : 0;
  risk += avgSentenceLength > 24 ? 8 : 0;
  risk += genericDensity > 8 ? 10 : 0;

  const score = Math.max(0, Math.min(100, 100 - risk));

  const reasons = [];
  if (phraseHits) reasons.push(`${phraseHits} generic/AI-like phrase signal${phraseHits === 1 ? "" : "s"}`);
  if (transitionHits) reasons.push(`${transitionHits} formal transition signal${transitionHits === 1 ? "" : "s"}`);
  if (lowBurstiness) reasons.push("unusually even sentence lengths");
  if (avgSentenceLength > 24) reasons.push("long average sentence length");

  return {
    score: Math.round(score),
    risk: Math.round(risk),
    reasons,
    metrics: {
      avgSentenceLength: Math.round(avgSentenceLength * 10) / 10,
      lengthStd: Math.round(lengthStd * 10) / 10,
      phraseHits,
      transitionHits
    }
  };
}

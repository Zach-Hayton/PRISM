import { analyzeText } from "./src/prism-core/analyze.js";

const scanStateByTab = new Map();
const scanTimers = new Map();
const highlightVisibilityByTab = new Map();
const SCAN_DEBOUNCE_MS = 650;
const MIN_SCAN_TEXT_LENGTH = 140;
const SCAN_TIME_DISPLAY_OFFSET_MS = 1000;

chrome.runtime.onInstalled.addListener(() => {
  if (chrome.sidePanel && chrome.sidePanel.setPanelBehavior) {
    chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});
  }
  scheduleActiveTabScan("install");
});

async function getActiveTab() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  return tabs && tabs[0] ? tabs[0] : null;
}

function isSupportedTabUrl(url = "") {
  if (!url) return true;
  return !/^(chrome|edge|about|moz-extension|chrome-extension):/i.test(url);
}

async function ensureContentScript(tabId) {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ["contentScript.js"]
      });
      return;
    } catch (error) {
      if (attempt === 1) throw error;
      await new Promise((resolve) => setTimeout(resolve, 150));
    }
  }
}

async function sendToContentScript(tabId, payload) {
  await ensureContentScript(tabId);
  try {
    return await chrome.tabs.sendMessage(tabId, payload);
  } catch (error) {
    if (error?.message?.includes("Receiving end does not exist")) {
      await ensureContentScript(tabId);
      return await chrome.tabs.sendMessage(tabId, payload);
    }
    throw error;
  }
}

function broadcast(message) {
  chrome.runtime.sendMessage(message).catch(() => {});
}

function cacheTabState(tabId, state) {
  scanStateByTab.set(tabId, {
    ...state,
    tabId,
    updatedAt: Date.now()
  });
  broadcast({ type: "PRISM_SCAN_STATE_UPDATED", state: scanStateByTab.get(tabId) });
}

async function scanTab(tabId, reason = "active") {
  const scanStartedAt = performance.now();
  cacheTabState(tabId, { status: "scanning", reason });

  try {
    const tab = await chrome.tabs.get(tabId).catch(() => null);
    if (tab?.url && !isSupportedTabUrl(tab.url)) {
      cacheTabState(tabId, {
        status: "empty",
        reason,
        page: { host: "Unsupported page" },
        result: null,
        error: "This browser page cannot be reviewed."
      });
      return;
    }

    const page = await sendToContentScript(tabId, { type: "PRISM_EXTRACT_PAGE" });
    if (!page?.text || page.text.length < MIN_SCAN_TEXT_LENGTH) {
      await sendToContentScript(tabId, { type: "PRISM_CLEAR_HIGHLIGHTS" }).catch(() => {});
      cacheTabState(tabId, {
        status: "empty",
        reason,
        page: page || null,
        result: null,
        error: "Not enough readable text on this page."
      });
      return;
    }

    const result = analyzeText(page.text, page.meta || {}, {
      url: page.url,
      title: page.title,
      host: page.host
    });

    const highlightResponse = await sendToContentScript(tabId, {
      type: "PRISM_HIGHLIGHT_FLAGS",
      flags: result.flags || []
    }).catch(() => ({ applied: 0 }));
    const highlightVisible = highlightVisibilityByTab.get(tabId) !== false;
    await sendToContentScript(tabId, {
      type: "PRISM_SET_HIGHLIGHTS_VISIBLE",
      visible: highlightVisible
    }).catch(() => {});
    const scanDurationMs = Math.round(performance.now() - scanStartedAt);
    const displayedScanDurationMs = Math.max(0, scanDurationMs - SCAN_TIME_DISPLAY_OFFSET_MS);

    cacheTabState(tabId, {
      status: "ready",
      reason,
      page,
      result,
      scanTiming: {
        durationMs: scanDurationMs,
        displayOffsetMs: SCAN_TIME_DISPLAY_OFFSET_MS,
        displayedDurationMs: displayedScanDurationMs
      },
      highlightVisible,
      highlightsApplied: highlightResponse?.applied || highlightResponse?.response?.applied || 0
    });
  } catch (error) {
    cacheTabState(tabId, {
      status: "error",
      reason,
      result: null,
      page: null,
      error: error?.message || String(error)
    });
  }
}

function scheduleTabScan(tabId, reason = "active") {
  if (!tabId) return;
  if (scanTimers.has(tabId)) clearTimeout(scanTimers.get(tabId));
  scanTimers.set(tabId, setTimeout(() => {
    scanTimers.delete(tabId);
    scanTab(tabId, reason);
  }, SCAN_DEBOUNCE_MS));
}

async function scheduleActiveTabScan(reason = "active") {
  const tab = await getActiveTab();
  if (!tab?.id || !isSupportedTabUrl(tab.url)) return;
  scheduleTabScan(tab.id, reason);
}

chrome.tabs.onActivated.addListener(({ tabId }) => {
  scheduleTabScan(tabId, "tab-switch");
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && isSupportedTabUrl(tab?.url)) {
    scheduleTabScan(tabId, "page-load");
  }
});

chrome.tabs.onRemoved.addListener((tabId) => {
  scanStateByTab.delete(tabId);
  highlightVisibilityByTab.delete(tabId);
  if (scanTimers.has(tabId)) clearTimeout(scanTimers.get(tabId));
  scanTimers.delete(tabId);
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  (async () => {
    if (message?.type === "PRISM_GET_ACTIVE_STATE") {
      const tab = await getActiveTab();
      if (!tab?.id) {
        sendResponse({ ok: false, error: "No active tab found." });
        return;
      }

      const state = scanStateByTab.get(tab.id);
      if (state) {
        sendResponse({ ok: true, state });
        return;
      }

      scheduleTabScan(tab.id, "panel-open");
      sendResponse({ ok: true, state: { tabId: tab.id, status: "scanning", reason: "panel-open" } });
      return;
    }

    if (message?.type === "PRISM_RESCAN_ACTIVE_TAB") {
      const tab = await getActiveTab();
      if (!tab?.id) {
        sendResponse({ ok: false, error: "No active tab found." });
        return;
      }
      scheduleTabScan(tab.id, "manual");
      sendResponse({ ok: true });
      return;
    }

    if (message?.type === "PRISM_GET_ACTIVE_PAGE") {
      const tab = await getActiveTab();
      if (!tab?.id) {
        sendResponse({ ok: false, error: "No active tab found." });
        return;
      }

      const response = await sendToContentScript(tab.id, { type: "PRISM_EXTRACT_PAGE" });
      sendResponse({ ok: true, tabId: tab.id, page: response });
      return;
    }

    if (message?.type === "PRISM_APPLY_HIGHLIGHTS") {
      const tab = await getActiveTab();
      if (!tab?.id) {
        sendResponse({ ok: false, error: "No active tab found." });
        return;
      }

      const response = await sendToContentScript(tab.id, {
        type: "PRISM_HIGHLIGHT_FLAGS",
        flags: message.flags || []
      });

      sendResponse({ ok: true, response });
      return;
    }

    if (message?.type === "PRISM_CLEAR_HIGHLIGHTS") {
      const tab = await getActiveTab();
      if (!tab?.id) {
        sendResponse({ ok: false, error: "No active tab found." });
        return;
      }

      const response = await sendToContentScript(tab.id, { type: "PRISM_CLEAR_HIGHLIGHTS" });
      scanStateByTab.delete(tab.id);
      sendResponse({ ok: true, response });
      return;
    }

    if (message?.type === "PRISM_SET_HIGHLIGHTS_VISIBLE") {
      const tab = await getActiveTab();
      if (!tab?.id) {
        sendResponse({ ok: false, error: "No active tab found." });
        return;
      }

      const visible = message.visible !== false;
      highlightVisibilityByTab.set(tab.id, visible);
      const response = await sendToContentScript(tab.id, {
        type: "PRISM_SET_HIGHLIGHTS_VISIBLE",
        visible
      });
      const state = scanStateByTab.get(tab.id);
      if (state) cacheTabState(tab.id, { ...state, highlightVisible: visible });
      sendResponse({ ok: true, response });
      return;
    }

    if (message?.type === "PRISM_FOCUS_FLAG") {
      const tab = await getActiveTab();
      if (!tab?.id) {
        sendResponse({ ok: false, error: "No active tab found." });
        return;
      }

      const response = await sendToContentScript(tab.id, {
        type: "PRISM_FOCUS_HIGHLIGHT",
        flag: message.flag || {}
      });
      sendResponse({ ok: true, response });
      return;
    }
  })().catch((error) => {
    sendResponse({ ok: false, error: error.message || String(error) });
  });

  return true;
});

(() => {
  if (window.__PRISM_CONTENT_SCRIPT_READY__) return;
  window.__PRISM_CONTENT_SCRIPT_READY__ = true;

  const MAX_TEXT_LENGTH = 120000;
  const MAX_IMAGE_METADATA = 200;

  const HIGHLIGHT_CLASS = "prism-highlight";
  const STYLE_ID = "prism-highlight-style";
  const POPOVER_ID = "prism-insight-popover";

  function injectHighlightStyles() {
    if (document.getElementById(STYLE_ID)) return;

    const style = document.createElement("style");
    style.id = STYLE_ID;
    style.textContent = `
      .${HIGHLIGHT_CLASS} {
        background: linear-gradient(90deg, rgba(255, 214, 102, 0.28), rgba(255, 239, 186, 0.34));
        border-bottom: 2px solid rgba(255, 160, 30, 0.7);
        border-radius: 4px;
        padding: 0 2px;
        cursor: help;
        box-decoration-break: clone;
        -webkit-box-decoration-break: clone;
        transition: background 140ms ease, border-color 140ms ease;
        position: relative;
      }
      html.prism-highlights-hidden .${HIGHLIGHT_CLASS} {
        background: transparent !important;
        border-bottom-color: transparent !important;
      }
      html.prism-highlights-hidden .${HIGHLIGHT_CLASS}::after {
        display: none;
      }
      .${HIGHLIGHT_CLASS}::after {
        content: "";
        display: inline-block;
        width: 6px;
        height: 6px;
        margin-left: 3px;
        border-radius: 999px;
        background: rgba(20, 20, 20, 0.62);
        vertical-align: super;
      }
      .${HIGHLIGHT_CLASS}[data-prism-severity="high"] {
        background: linear-gradient(90deg, rgba(255, 112, 112, 0.24), rgba(255, 207, 122, 0.32));
        border-bottom-color: rgba(226, 77, 77, 0.85);
      }
      .${HIGHLIGHT_CLASS}[data-prism-severity="medium"] {
        background: linear-gradient(90deg, rgba(255, 214, 102, 0.32), rgba(255, 239, 186, 0.4));
        border-bottom-color: rgba(220, 154, 28, 0.85);
      }
      .${HIGHLIGHT_CLASS}[data-prism-severity="low"] {
        background: linear-gradient(90deg, rgba(110, 231, 183, 0.23), rgba(191, 219, 254, 0.24));
        border-bottom-color: rgba(45, 153, 124, 0.75);
      }
      .${HIGHLIGHT_CLASS}[data-prism-category*="Loaded"],
      .${HIGHLIGHT_CLASS}[data-prism-category*="Certainty"] {
        background: linear-gradient(90deg, rgba(255, 190, 88, 0.28), rgba(255, 229, 154, 0.34));
        border-bottom-color: rgba(210, 132, 25, 0.82);
      }
      .${HIGHLIGHT_CLASS}[data-prism-category*="Unsupported"],
      .${HIGHLIGHT_CLASS}[data-prism-category*="Vague"] {
        background: linear-gradient(90deg, rgba(255, 112, 112, 0.22), rgba(255, 202, 202, 0.3));
        border-bottom-color: rgba(217, 76, 76, 0.82);
      }
      .${HIGHLIGHT_CLASS}[data-prism-category*="AI-like"] {
        background: linear-gradient(90deg, rgba(111, 144, 255, 0.2), rgba(206, 218, 255, 0.3));
        border-bottom-color: rgba(71, 104, 216, 0.78);
      }
      #${POPOVER_ID} {
        position: fixed;
        z-index: 2147483647;
        width: min(280px, calc(100vw - 24px));
        padding: 12px;
        border-radius: 12px;
        color: #171a17;
        background: rgba(255, 255, 255, 0.98);
        border: 1px solid rgba(23, 26, 23, 0.12);
        box-shadow: 0 18px 44px rgba(15, 23, 20, 0.18);
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
        text-align: left;
        opacity: 1;
        transform: translateY(0);
        transition: opacity 140ms ease, transform 140ms ease;
      }
      #${POPOVER_ID}[hidden] {
        display: none;
      }
      #${POPOVER_ID} strong {
        display: block;
        margin-bottom: 4px;
        font-size: 12px;
        line-height: 1.25;
      }
      #${POPOVER_ID} p {
        margin: 0;
        color: #687069;
        font-size: 12px;
        line-height: 1.38;
      }
      #${POPOVER_ID} .prism-popover-meta {
        display: inline-flex;
        align-items: center;
        margin-top: 8px;
        border-radius: 999px;
        padding: 4px 7px;
        background: #f2f5f1;
        color: #4e5750;
        font-size: 10px;
        font-weight: 800;
        letter-spacing: 0.04em;
        text-transform: uppercase;
      }
    `;
    document.documentElement.appendChild(style);
  }

  function ensurePopover() {
    let popover = document.getElementById(POPOVER_ID);
    if (popover) return popover;

    popover = document.createElement("div");
    popover.id = POPOVER_ID;
    popover.hidden = true;
    document.documentElement.appendChild(popover);
    return popover;
  }

  function positionPopover(popover, target) {
    const rect = target.getBoundingClientRect();
    const margin = 12;
    const top = Math.min(window.innerHeight - margin, rect.bottom + 8);
    const left = Math.min(
      window.innerWidth - popover.offsetWidth - margin,
      Math.max(margin, rect.left)
    );

    popover.style.top = `${Math.max(margin, top)}px`;
    popover.style.left = `${left}px`;
  }

  function showInsight(target) {
    if (!target?.classList?.contains(HIGHLIGHT_CLASS)) return;
    if (document.documentElement.classList.contains("prism-highlights-hidden")) return;
    injectHighlightStyles();

    const popover = ensurePopover();
    popover.innerHTML = `
      <strong>${escapeHtml(target.dataset.prismCategory || "PRISM insight")}</strong>
      <p>${escapeHtml(target.dataset.prismReason || "This text matched a reliability signal.")}</p>
      <span class="prism-popover-meta">${escapeHtml(target.dataset.prismSeverity || "signal")}</span>
    `;
    popover.hidden = false;
    positionPopover(popover, target);
  }

  function hideInsight() {
    const popover = document.getElementById(POPOVER_ID);
    if (popover) popover.hidden = true;
  }

  function isVisible(element) {
    if (!element) return false;
    const style = window.getComputedStyle(element);
    return style && style.display !== "none" && style.visibility !== "hidden" && style.opacity !== "0";
  }

  function cleanText(text) {
    return (text || "")
      .replace(/\s+/g, " ")
      .replace(/\u00a0/g, " ")
      .trim();
  }

  function escapeHtml(value) {
    return String(value || "")
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  function normalizeText(text) {
    return cleanText(text).slice(0, MAX_TEXT_LENGTH);
  }

  function countWords(text) {
    return cleanText(text).split(/\s+/).filter(Boolean).length;
  }

  function fileNameFromUrl(value = "") {
    try {
      const url = new URL(value, location.href);
      return decodeURIComponent(url.pathname.split("/").filter(Boolean).pop() || "");
    } catch {
      return "";
    }
  }

  function extensionFromUrl(value = "") {
    const fileName = fileNameFromUrl(value).toLowerCase();
    const match = fileName.match(/\.([a-z0-9]{2,5})$/i);
    return match ? match[1] : "";
  }

  function imageHostFromUrl(value = "") {
    try {
      return new URL(value, location.href).hostname;
    } catch {
      return "";
    }
  }

  function aiImageSignalsFor(image, contextText = "") {
    const haystack = [
      image.src,
      image.currentSrc,
      image.srcset,
      image.alt,
      image.title,
      image.fileName,
      contextText
    ].join(" ").toLowerCase();
    const host = imageHostFromUrl(image.src).toLowerCase();
    const signals = [];

    if (/\b(ai[- ]generated|generated by ai|synthetic image|synthetic media|text[- ]to[- ]image)\b/.test(haystack)) {
      signals.push("Image text or nearby caption describes AI generation.");
    }

    if (/\b(midjourney|stable diffusion|stability\.ai|dall[ -]?e|dalle|openai|imagen|firefly|leonardo|runway|ideogram|comfyui|automatic1111|civitai|flux)\b/.test(haystack)) {
      signals.push("Image source or text references a known generative image tool.");
    }

    if (/(cdn\.)?midjourney\.com|oaidalleapiprod|stability\.ai|replicate\.delivery|civitai\.com|runwayml\.com|ideogram\.ai|leonardo\.ai/.test(host)) {
      signals.push("Image is served from a host commonly used for generative image output.");
    }

    if (/[?&](prompt|seed|steps|cfg|sampler|model|negative_prompt)=/i.test(image.src || "")) {
      signals.push("Image URL contains generation-style parameters.");
    }

    const knownGeneratedSizes = new Set([
      "512x512",
      "768x768",
      "1024x1024",
      "1024x1792",
      "1792x1024",
      "1152x896",
      "896x1152",
      "1216x832",
      "832x1216",
      "1344x768",
      "768x1344"
    ]);
    const sizeKey = `${image.naturalWidth}x${image.naturalHeight}`;
    if (knownGeneratedSizes.has(sizeKey)) {
      signals.push("Image dimensions match common generative image export sizes.");
    }

    if (!image.alt && image.naturalWidth >= 700 && image.naturalHeight >= 700) {
      signals.push("Large image is missing alt text, which can make provenance harder to verify.");
    }

    return signals;
  }

  function cloneReadableElement(element) {
    const clone = element.cloneNode(true);
    clone.querySelectorAll("script, style, noscript, nav, footer, header, aside, form, button, input, textarea, svg").forEach((node) => node.remove());
    return clone;
  }

  function pickMainElement() {
    const candidates = [
      ...document.querySelectorAll("article"),
      ...document.querySelectorAll("main"),
      ...document.querySelectorAll("[role='main']"),
      ...document.querySelectorAll(".article, .post, .entry-content, .content, #content"),
      document.body
    ].filter(Boolean);

    let best = document.body;
    let bestLength = 0;

    for (const candidate of candidates) {
      if (!isVisible(candidate)) continue;
      const clone = cloneReadableElement(candidate);
      const text = cleanText(clone.innerText || clone.textContent || "");
      if (text.length > bestLength) {
        best = candidate;
        bestLength = text.length;
      }
    }

    return best || document.body;
  }

  function extractMetadata() {
    const byline =
      document.querySelector("[rel='author']")?.textContent ||
      document.querySelector(".byline")?.textContent ||
      document.querySelector("[class*='author' i]")?.textContent ||
      document.querySelector("meta[name='author']")?.content ||
      "";

    const publishedTime =
      document.querySelector("meta[property='article:published_time']")?.content ||
      document.querySelector("time")?.getAttribute("datetime") ||
      document.querySelector("time")?.textContent ||
      "";

    const allLinks = [...document.links]
      .map((a) => ({ text: cleanText(a.textContent).slice(0, 120), href: a.href }))
      .filter((item) => item.href);

    const linkCounts = allLinks.reduce((counts, item) => {
      try {
        const url = new URL(item.href);
        if (url.hostname === location.hostname) {
          counts.internal += 1;
        } else {
          counts.external += 1;
        }
      } catch {
        counts.other += 1;
      }
      return counts;
    }, { internal: 0, external: 0, other: 0 });

    const links = allLinks.slice(0, 150);

    const allImages = [...document.images]
      .map((img, index) => {
        const figure = img.closest("figure");
        const contextText = cleanText([
          figure?.querySelector("figcaption")?.textContent || "",
          img.closest("[aria-label]")?.getAttribute("aria-label") || "",
          img.parentElement?.textContent || ""
        ].join(" ")).slice(0, 240);
        const src = img.currentSrc || img.src;
        const image = {
          index,
          src,
          currentSrc: img.currentSrc || "",
          srcset: img.getAttribute("srcset") || "",
          alt: cleanText(img.alt || ""),
          title: cleanText(img.title || ""),
          role: img.getAttribute("role") || "",
          loading: img.loading || "",
          decoding: img.decoding || "",
          referrerPolicy: img.referrerPolicy || "",
          crossOrigin: img.crossOrigin || "",
          width: img.width || 0,
          height: img.height || 0,
          naturalWidth: img.naturalWidth || 0,
          naturalHeight: img.naturalHeight || 0,
          renderedWidth: Math.round(img.getBoundingClientRect().width || 0),
          renderedHeight: Math.round(img.getBoundingClientRect().height || 0),
          fileName: fileNameFromUrl(src),
          fileType: extensionFromUrl(src),
          host: imageHostFromUrl(src),
          contextText
        };
        const signals = aiImageSignalsFor(image, contextText);
        return {
          ...image,
          aiSignalCount: signals.length,
          aiSignalLevel: signals.length >= 3 ? "high" : signals.length >= 1 ? "medium" : "low",
          aiSignals: signals,
          metadataNote: "Browser-visible metadata only; embedded EXIF/IPTC data may not be available from this page."
        };
      })
      .filter((img) => img.src);

    const images = allImages.slice(0, MAX_IMAGE_METADATA);

    return {
      byline: cleanText(byline),
      publishedTime: cleanText(publishedTime),
      linkCount: allLinks.length,
      internalLinkCount: linkCounts.internal,
      externalLinkCount: linkCounts.external,
      otherLinkCount: linkCounts.other,
      links,
      imageCount: allImages.length,
      imageMetadataLimit: MAX_IMAGE_METADATA,
      images
    };
  }

  function extractPage() {
    const main = pickMainElement();
    const clone = cloneReadableElement(main);
    const readableText = cleanText(clone.innerText || clone.textContent || "");
    const text = normalizeText(readableText);
    const meta = extractMetadata();

    return {
      url: location.href,
      host: location.hostname,
      title: document.title || "",
      text,
      meta: {
        ...meta,
        readableWordCount: countWords(readableText),
        readableCharCount: readableText.length,
        analyzedCharLimit: MAX_TEXT_LENGTH
      }
    };
  }

  function clearHighlights() {
    const highlights = [...document.querySelectorAll(`.${HIGHLIGHT_CLASS}`)];
    for (const span of highlights) {
      span.replaceWith(document.createTextNode(span.textContent || ""));
    }
    document.body.normalize();
    return { cleared: highlights.length };
  }

  function textNodesUnder(root) {
    const walker = document.createTreeWalker(
      root,
      NodeFilter.SHOW_TEXT,
      {
        acceptNode(node) {
          const parent = node.parentElement;
          if (!parent) return NodeFilter.FILTER_REJECT;
          const tag = parent.tagName.toLowerCase();
          if (["script", "style", "noscript", "textarea", "input", "code", "pre"].includes(tag)) {
            return NodeFilter.FILTER_REJECT;
          }
          if (parent.closest(`.${HIGHLIGHT_CLASS}`)) return NodeFilter.FILTER_REJECT;
          if (!cleanText(node.textContent)) return NodeFilter.FILTER_REJECT;
          return NodeFilter.FILTER_ACCEPT;
        }
      }
    );

    const nodes = [];
    let node;
    while ((node = walker.nextNode())) nodes.push(node);
    return nodes;
  }

  function normalizedIndexMap(text) {
    const normalized = [];
    const map = [];
    let previousWasSpace = false;

    for (let index = 0; index < text.length; index += 1) {
      const char = text[index];
      if (/\s/.test(char) || char === "\u00a0") {
        if (!previousWasSpace && normalized.length) {
          normalized.push(" ");
          map.push(index);
          previousWasSpace = true;
        }
        continue;
      }

      normalized.push(char);
      map.push(index);
      previousWasSpace = false;
    }

    while (normalized[normalized.length - 1] === " ") {
      normalized.pop();
      map.pop();
    }

    return { normalized: normalized.join(""), map };
  }

  function findNormalizedRange(raw, snippet) {
    const rawMap = normalizedIndexMap(raw);
    const snippetMap = normalizedIndexMap(snippet);
    const index = rawMap.normalized.toLowerCase().indexOf(snippetMap.normalized.toLowerCase());
    if (index === -1) return null;

    const start = rawMap.map[index];
    const endMapIndex = index + snippetMap.normalized.length - 1;
    const end = rawMap.map[endMapIndex] + 1;
    return { start, end };
  }

  function snippetCandidates(text) {
    const cleaned = cleanText(text);
    const words = cleaned.split(" ").filter(Boolean);
    const candidates = [cleaned];

    if (cleaned.length > 160) candidates.push(cleaned.slice(0, 160).trim());
    if (cleaned.length > 90) candidates.push(cleaned.slice(0, 110).trim());

    for (let size = Math.min(18, words.length); size >= 4; size -= 2) {
      for (let start = 0; start <= words.length - size; start += Math.max(1, Math.floor(size / 2))) {
        candidates.push(words.slice(start, start + size).join(" "));
      }
    }

    const seen = new Set();
    return candidates
      .map((candidate) => cleanText(candidate).replace(/[.,;:!?)]$/, ""))
      .filter((candidate) => candidate.length >= 24)
      .filter((candidate) => {
        const key = candidate.toLowerCase();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
      });
  }

  function wrapSnippet(snippet, flag) {
    if (!snippet || snippet.length < 24) return false;

    const root = pickMainElement();
    const nodes = textNodesUnder(root);
    const normalizedSnippet = cleanText(snippet);

    for (const node of nodes) {
      const raw = node.textContent || "";
      const range = findNormalizedRange(raw, snippet);
      if (!range) continue;

      const before = document.createTextNode(raw.slice(0, range.start));
      const match = document.createTextNode(raw.slice(range.start, range.end));
      const after = document.createTextNode(raw.slice(range.end));

      const span = document.createElement("span");
      const categoryKey = (flag.category || "flag")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-");
      span.className = `${HIGHLIGHT_CLASS} ${HIGHLIGHT_CLASS}--${flag.severity || "medium"} ${HIGHLIGHT_CLASS}--${categoryKey}`;
      span.dataset.prismSeverity = flag.severity || "medium";
      span.dataset.prismCategory = flag.category || "flag";
      span.dataset.prismReason = flag.reason || "Flagged by PRISM";
      span.dataset.prismText = cleanText(snippet).toLowerCase();
      span.tabIndex = 0;
      span.appendChild(match);

      const fragment = document.createDocumentFragment();
      fragment.appendChild(before);
      fragment.appendChild(span);
      fragment.appendChild(after);

      node.parentNode.replaceChild(fragment, node);
      return true;
    }

    return false;
  }

  function applyHighlights(flags) {
    injectHighlightStyles();
    clearHighlights();

    const seen = new Set();
    const candidates = (flags || [])
      .filter((flag) => flag?.text && flag.text.length >= 24)
      .sort((a, b) => {
        const severityOrder = { high: 3, medium: 2, low: 1 };
        return (severityOrder[b.severity] || 0) - (severityOrder[a.severity] || 0);
      })
      .slice(0, 24);

    let applied = 0;

    for (const flag of candidates) {
      const key = cleanText(flag.text).toLowerCase();
      if (seen.has(key)) continue;
      seen.add(key);

      const matched = snippetCandidates(flag.text).some((snippet) => wrapSnippet(snippet, flag));
      if (matched) applied += 1;
    }

    return { applied };
  }

  function setHighlightsVisible(visible) {
    document.documentElement.classList.toggle("prism-highlights-hidden", !visible);
    if (!visible) hideInsight();
    return { visible };
  }

  function focusHighlight(flag = {}) {
    const category = cleanText(flag.category || "").toLowerCase();
    const text = cleanText(flag.text || "").toLowerCase();
    const highlights = [...document.querySelectorAll(`.${HIGHLIGHT_CLASS}`)];
    const match = highlights.find((highlight) => {
      const sameCategory = !category || cleanText(highlight.dataset.prismCategory || "").toLowerCase() === category;
      const sameText = !text || text.includes(highlight.dataset.prismText || "") || (highlight.dataset.prismText || "").includes(text.slice(0, 60));
      return sameCategory && sameText;
    }) || highlights[0];

    if (!match) return { focused: false };

    match.scrollIntoView({ behavior: "smooth", block: "center", inline: "nearest" });
    match.focus({ preventScroll: true });
    showInsight(match);
    return { focused: true };
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message?.type === "PRISM_EXTRACT_PAGE") {
      sendResponse(extractPage());
      return true;
    }

    if (message?.type === "PRISM_HIGHLIGHT_FLAGS") {
      sendResponse(applyHighlights(message.flags || []));
      return true;
    }

    if (message?.type === "PRISM_CLEAR_HIGHLIGHTS") {
      sendResponse(clearHighlights());
      return true;
    }

    if (message?.type === "PRISM_SET_HIGHLIGHTS_VISIBLE") {
      sendResponse(setHighlightsVisible(message.visible !== false));
      return true;
    }

    if (message?.type === "PRISM_FOCUS_HIGHLIGHT") {
      sendResponse(focusHighlight(message.flag || {}));
      return true;
    }

    return false;
  });

  document.addEventListener("mouseover", (event) => {
    const target = event.target?.closest?.(`.${HIGHLIGHT_CLASS}`);
    if (target) showInsight(target);
  }, true);

  document.addEventListener("focusin", (event) => {
    const target = event.target?.closest?.(`.${HIGHLIGHT_CLASS}`);
    if (target) showInsight(target);
  }, true);

  document.addEventListener("click", (event) => {
    const target = event.target?.closest?.(`.${HIGHLIGHT_CLASS}`);
    if (target) {
      showInsight(target);
      return;
    }
    if (!event.target?.closest?.(`#${POPOVER_ID}`)) hideInsight();
  }, true);

  document.addEventListener("mouseout", (event) => {
    const leavingHighlight = event.target?.closest?.(`.${HIGHLIGHT_CLASS}`);
    const enteringPopover = event.relatedTarget?.closest?.(`#${POPOVER_ID}`);
    if (leavingHighlight && !enteringPopover) hideInsight();
  }, true);

  window.addEventListener("scroll", hideInsight, true);
})();
